<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

$user = require_login();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
$isDemo = ($user['demo_mode'] ?? false) === true;
$isAdmin = $user['role'] === 'admin';
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isAdmin) {
    $fullName = input_string('full_name');
    $email = input_string('email');
    $role = input_string('role');
    $password = input_string('password');
    $allowedRoles = ['admin', 'principal', 'teacher', 'parent'];

    if (!valid_csrf_token()) {
        $error = 'Your session expired. Refresh the page and try again.';
    } elseif ($fullName === '' || strlen($fullName) > 160) {
        $error = 'Enter a name up to 160 characters long.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
        $error = 'Enter a valid email address.';
    } elseif (!in_array($role, $allowedRoles, true)) {
        $error = 'Choose a valid account role.';
    } elseif (strlen($password) < 12) {
        $error = 'Choose a password with at least 12 characters.';
    } else {
        try {
            $statement = database()->prepare(
                'INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)'
            );
            $statement->execute([$fullName, $email, password_hash($password, PASSWORD_DEFAULT), $role]);
            $success = 'Account created. Share the sign-in details with the account holder securely.';
        } catch (PDOException $exception) {
            $error = $exception->getCode() === '23000'
                ? 'An account already uses that email address.'
                : 'The account could not be created. Please try again.';
        }
    }
}

$accounts = [];
$subscribers = [];
if ($isAdmin) {
    $pdo = database();
    $accounts = $pdo->query('SELECT full_name, email, role, is_active, created_at FROM users ORDER BY created_at DESC')->fetchAll();
    $subscribers = $pdo->query('SELECT email, created_at FROM subscribers ORDER BY created_at DESC')->fetchAll();
}
$activeAccountCount = count(array_filter($accounts, static fn (array $account): bool => (bool) $account['is_active']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Registered Accounts | EARS</title>
    <link rel="stylesheet" href="auth.css">
</head>
<body class="app-page">
<div class="app-shell">
    <header class="app-nav">
        <a class="brand" href="index.php"><span class="brand-mark">E</span><span>EARS</span></a>
        <form method="post" action="logout.php">
            <input type="hidden" name="csrf_token" value="<?= escape(csrf_token()) ?>">
            <button class="text-button" type="submit">Sign out</button>
        </form>
    </header>
    <main class="app-content">
        <?php if (!$isDemo): ?>
            <section class="app-heading">
                <div>
                    <p class="eyebrow">Elementary Assessment and Recommendation System</p>
                    <h1>Welcome, <?= escape($user['full_name']) ?></h1>
                    <p>Signed in as <?= escape($user['email']) ?>.</p>
                </div>
                <span class="role-label"><?= escape($user['role']) ?></span>
            </section>
        <?php endif; ?>

        <?php if ($isAdmin): ?>
            <section class="content-section" aria-labelledby="accounts-heading">
                <div class="account-section-heading">
                    <div>
                        <h2 id="accounts-heading">All Registered Accounts <span class="account-count">(<?= number_format(count($accounts)) ?>)</span></h2>
                        <p>Create sign-in accounts for school staff and families.</p>
                    </div>
                    <button class="dashboard-refresh" type="button" onclick="window.location.reload()" aria-label="Refresh account list" title="Refresh account list"><span aria-hidden="true">&#8635;</span> Refresh</button>
                </div>
                <?php if ($error !== ''): ?><div class="alert" role="alert"><?= escape($error) ?></div><?php endif; ?>
                <?php if ($success !== ''): ?><div class="alert success" role="status"><?= escape($success) ?></div><?php endif; ?>

                <div class="account-stats" aria-label="Account statistics">
                    <div class="account-stat"><span>Total registered accounts</span><strong><?= number_format(count($accounts)) ?></strong></div>
                    <div class="account-stat"><span>Active accounts</span><strong><?= number_format($activeAccountCount) ?></strong></div>
                    <div class="account-stat"><span>Subscribers</span><strong><?= number_format(count($subscribers)) ?></strong></div>
                </div>

                <div class="admin-layout">
                    <form method="post" action="dashboard.php" autocomplete="off">
                        <input type="hidden" name="csrf_token" value="<?= escape(csrf_token()) ?>">
                        <div class="field">
                            <label for="full_name">Full name</label>
                            <input id="full_name" name="full_name" type="text" maxlength="160" required>
                        </div>
                        <div class="field">
                            <label for="email">Email address</label>
                            <input id="email" name="email" type="email" maxlength="190" required>
                        </div>
                        <div class="field">
                            <label for="role">Role</label>
                            <select id="role" name="role" required>
                                <option value="teacher">Teacher</option>
                                <option value="parent">Parent or guardian</option>
                                <option value="principal">Principal</option>
                                <option value="admin">Administrator</option>
                            </select>
                        </div>
                        <div class="field">
                            <label for="password">Temporary password (12+ characters)</label>
                            <input id="password" name="password" type="password" minlength="12" autocomplete="new-password" required>
                        </div>
                        <button class="primary-button" type="submit">Create account</button>
                    </form>

                    <div class="accounts-browser">
                        <label class="visually-hidden" for="account-search">Search accounts by name or email</label>
                        <input class="account-search" id="account-search" type="search" placeholder="Search by name or email..." autocomplete="off">
                        <?php if ($accounts): ?>
                            <div class="account-table-wrap">
                            <table class="account-list">
                                <thead><tr><th>#</th><th>Full name</th><th>Email address</th><th>Role</th><th>Registered</th><th>Status</th></tr></thead>
                                <tbody>
                                <?php foreach ($accounts as $index => $account): ?>
                                    <tr data-account-row>
                                        <td><?= $index + 1 ?></td>
                                        <td><strong><?= escape($account['full_name']) ?></strong></td>
                                        <td><?= escape($account['email']) ?></td>
                                        <td class="account-role"><?= escape($account['role']) ?></td>
                                        <td><?= escape(date('M j, Y g:i A', strtotime($account['created_at']))) ?></td>
                                        <td><span class="account-status <?= $account['is_active'] ? 'is-active' : 'is-inactive' ?>"><?= $account['is_active'] ? 'Active' : 'Inactive' ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                                    <tr class="account-no-results" hidden><td colspan="6">No matching accounts found.</td></tr>
                                </tbody>
                            </table>
                            </div>
                        <?php else: ?>
                            <p class="empty-state">No accounts have been created.</p>
                        <?php endif; ?>
                        <p class="account-results" id="account-results" aria-live="polite"></p>
                    </div>
                </div>
            </section>
            <section class="content-section" aria-labelledby="subscribers-heading">
                <h2 id="subscribers-heading">All Subscribes <span class="account-count">(<?= number_format(count($subscribers)) ?>)</span></h2>
                <p>Email addresses subscribed to system news and updates.</p>
                <?php if ($subscribers): ?>
                    <table class="account-list">
                        <thead><tr><th>Email</th><th>Date subscribed</th></tr></thead>
                        <tbody>
                        <?php foreach ($subscribers as $subscriber): ?>
                            <tr>
                                <td><?= escape($subscriber['email']) ?></td>
                                <td><?= escape(date('M j, Y', strtotime($subscriber['created_at']))) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="empty-state">No subscribers yet.</p>
                <?php endif; ?>
            </section>
        <?php elseif (!$isDemo): ?>
            <section class="content-section">
                <h2>Your account is ready</h2>
                <p>You are signed in. Assessment and learner tools can be connected to this account as those sections are added.</p>
            </section>
        <?php endif; ?>
    </main>
</div>
<?php if ($isAdmin && $accounts): ?>
<script>
    const accountSearch = document.getElementById('account-search');
    const accountRows = Array.from(document.querySelectorAll('[data-account-row]'));
    const noAccountResults = document.querySelector('.account-no-results');
    const accountResults = document.getElementById('account-results');

    function filterAccounts() {
        const query = accountSearch.value.trim().toLocaleLowerCase();
        let visibleCount = 0;

        accountRows.forEach((row) => {
            const matches = row.textContent.toLocaleLowerCase().includes(query);
            row.hidden = !matches;
            visibleCount += matches ? 1 : 0;
        });

        noAccountResults.hidden = visibleCount !== 0;
        accountResults.textContent = query
            ? `Showing ${visibleCount} of ${accountRows.length} accounts`
            : '';
    }

    accountSearch.addEventListener('input', filterAccounts);
</script>
<?php endif; ?>
</body>
</html>