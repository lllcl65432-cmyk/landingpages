<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && input_string('action') === 'subscribe') {
    $email = input_string('email');
    $message = '';
    $messageType = 'error';

    if (!valid_csrf_token()) {
        $message = 'Your session expired. Refresh the page and try again.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
        $message = 'Enter a valid email address.';
    } else {
        try {
            $statement = database()->prepare('INSERT INTO subscribers (email) VALUES (?)');
            $statement->execute([$email]);
            $message = 'Successfully subscribed! Thank you.';
            $messageType = 'success';
        } catch (PDOException $exception) {
            if ($exception->getCode() === '23000') {
                $message = 'This email is already subscribed. Thank you!';
                $messageType = 'info';
            } else {
                $message = 'Subscription could not be saved. Please try again later.';
            }
        }
    }

    $_SESSION['subscribe_message'] = $message;
    $_SESSION['subscribe_message_type'] = $messageType;
    header('Location: index.php#subscribe');
    exit;
}

$registeredCount = 0;
$subscriberCount = 0;
try {
    $pdo = database();
    $registeredCount = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    $subscriberCount = (int) $pdo->query('SELECT COUNT(*) FROM subscribers')->fetchColumn();
} catch (PDOException $exception) {
    // Keep the public page available while the database is being configured.
}

$subscribeMessage = $_SESSION['subscribe_message'] ?? '';
$subscribeMessageType = $_SESSION['subscribe_message_type'] ?? '';
unset($_SESSION['subscribe_message'], $_SESSION['subscribe_message_type']);
$registrationMessage = $_SESSION['registration_message'] ?? (isset($_GET['registered']) ? 'Account created successfully. You can now sign in.' : '');
$registrationMessageType = $_SESSION['registration_message_type'] ?? 'success';
$registrationName = $_SESSION['registration_name'] ?? '';
$registrationEmail = $_SESSION['registration_email'] ?? '';
unset($_SESSION['registration_message'], $_SESSION['registration_message_type'], $_SESSION['registration_name'], $_SESSION['registration_email']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elementary Assessment and Recommendation System</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #1e5799;
            --primary-dark: #15457a;
            --secondary: #2989d8;
            --accent: #f9a825;
            --accent-dark: #f57c00;
            --light: #f0f6fc;
            --dark: #1e293b;
            --muted: #64748b;
            --card-bg: #ffffff;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 12px rgba(30, 87, 153, 0.08);
            --shadow-lg: 0 12px 40px rgba(30, 87, 153, 0.15);
            --radius: 14px;
            --radius-sm: 8px;
        }

        body {
            line-height: 1.7;
            color: var(--dark);
            background-color: #fafcfe;
        }

        html {
            scroll-behavior: smooth;
        }

        /* === TOOLTIP SYSTEM === */
        .tooltip {
            position: relative;
            display: inline-flex;
            align-items: center;
            cursor: help;
        }

        .tooltip-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 20px;
            height: 20px;
            margin-left: 8px;
            border-radius: 50%;
            background: rgba(30, 87, 153, 0.12);
            color: var(--primary);
            font-size: 12px;
            font-weight: 700;
            transition: all 0.25s ease;
            flex-shrink: 0;
        }

        .tooltip:hover .tooltip-icon {
            background: var(--primary);
            color: #fff;
        }

        .tooltip-text {
            visibility: hidden;
            opacity: 0;
            position: absolute;
            bottom: calc(100% + 10px);
            left: auto;
            right: 0;
            transform: translateY(6px);
            background: var(--dark);
            color: #fff;
            font-size: 13px;
            line-height: 1.5;
            padding: 10px 14px;
            border-radius: 8px;
            width: max-content;
            min-width: 220px;
            max-width: 280px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.2);
            z-index: 999;
            transition: all 0.25s ease;
            pointer-events: none;
        }

        .tooltip-text::after {
            content: '';
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%);
            border-width: 6px;
            border-style: solid;
            border-color: var(--dark) transparent transparent transparent;
        }

        .tooltip:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
            transform: translateY(0);
        }

        /* Navigation */
        nav {
            background: rgba(255, 255, 255, 0.92);
            backdrop-filter: blur(8px);
            box-shadow: var(--shadow-sm);
            padding: 1rem 5%;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--primary);
            letter-spacing: -0.3px;
        }

        .nav-links a {
            margin-left: 2rem;
            text-decoration: none;
            color: var(--dark);
            font-weight: 500;
            position: relative;
            transition: color 0.25s ease;
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--accent);
            transition: width 0.3s ease;
        }

        .nav-links a:hover {
            color: var(--primary);
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        .btn-login {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: #fff !important;
            padding: 0.7rem 1.6rem;
            border-radius: var(--radius-sm);
            transition: transform 0.25s, box-shadow 0.25s;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 18px rgba(30, 87, 153, 0.3);
        }

        .btn-login::after {
            display: none;
        }

        /* Hero Section with School Background */
        .hero {
            position: relative;
            min-height: 85vh;
            display: flex;
            align-items: center;
            padding: 5rem 5%;
            overflow: hidden;
        }

        .hero-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('https://images.unsplash.com/photo-1509062522246-3755977927d7?w=1600&q=85') center/cover no-repeat;
            z-index: -2;
        }

        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(30, 87, 153, 0.88) 0%, rgba(41, 137, 216, 0.82) 100%);
            z-index: -1;
        }

        .hero-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4rem;
            align-items: center;
            width: 100%;
        }

        .hero-content {
            animation: fadeInUp 0.8s ease-out;
            color: white;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(24px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .hero h1 {
            font-size: 2.6rem;
            line-height: 1.2;
            margin-bottom: 1.5rem;
            letter-spacing: -0.5px;
            text-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }

        .hero p {
            font-size: 1.15rem;
            margin-bottom: 2.2rem;
            opacity: 0.94;
            text-shadow: 0 1px 4px rgba(0,0,0,0.1);
        }

        .btn-primary {
            display: inline-block;
            background: linear-gradient(135deg, var(--accent) 0%, #ffb300 100%);
            color: #fff;
            padding: 1rem 2.2rem;
            border-radius: var(--radius-sm);
            text-decoration: none;
            font-weight: 600;
            font-size: 1rem;
            box-shadow: 0 6px 20px rgba(249, 168, 37, 0.35);
            transition: transform 0.3s, box-shadow 0.3s, background 0.3s;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, var(--accent-dark) 0%, #ffa000 100%);
            transform: translateY(-3px);
            box-shadow: 0 10px 28px rgba(249, 168, 37, 0.4);
        }

        .btn-secondary {
            display: inline-block;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            padding: 1rem 2.2rem;
            border-radius: var(--radius-sm);
            text-decoration: none;
            font-weight: 600;
            margin-left: 1rem;
            border: 2px solid rgba(255, 255, 255, 0.35);
            transition: background 0.3s, transform 0.3s, border-color 0.3s;
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
            border-color: rgba(255, 255, 255, 0.5);
        }

        .hero-graphic {
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-12px); }
        }

        /* Features Section */
        .features {
            padding: 5rem 5%;
            background: var(--light);
        }

        .section-heading {
            text-align: center;
            max-width: 720px;
            margin: 0 auto 3.5rem;
        }

        .section-heading h2 {
            font-size: 2.1rem;
            color: var(--primary);
            margin-bottom: 0.8rem;
        }

        .section-heading p {
            font-size: 1.08rem;
            color: var(--muted);
        }

        .features-grid {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.8rem;
        }

        .feature-card {
            background: var(--card-bg);
            padding: 2.2rem;
            border-radius: var(--radius);
            box-shadow: var(--shadow-md);
            transition: transform 0.35s ease, box-shadow 0.35s ease;
            border-top: 4px solid transparent;
            background-clip: padding-box;
        }

        .feature-card:nth-child(1) { border-top-color: var(--primary); }
        .feature-card:nth-child(2) { border-top-color: var(--secondary); }
        .feature-card:nth-child(3) { border-top-color: var(--accent); }
        .feature-card:nth-child(4) { border-top-color: #43a047; }
        .feature-card:nth-child(5) { border-top-color: #e53935; }
        .feature-card:nth-child(6) { border-top-color: #8e24aa; }

        .feature-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-lg);
        }

        .feature-card h3 {
            color: var(--primary);
            margin-bottom: 0.9rem;
            font-size: 1.15rem;
            display: flex;
            align-items: center;
        }

        .feature-card p {
            color: var(--muted);
            font-size: 0.98rem;
        }

        /* Who We Serve */
        .serve {
            padding: 5rem 5%;
            background: #fff;
        }

        .serve-grid {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 2rem;
        }

        .serve-card {
            padding: 2.5rem 2rem;
            border-radius: var(--radius);
            border: 2px solid #e8eff7;
            text-align: center;
            transition: all 0.35s ease;
            background: linear-gradient(to bottom, #fff, #f8fbfe);
        }

        .serve-card:hover {
            border-color: var(--primary);
            transform: translateY(-6px);
            box-shadow: var(--shadow-lg);
        }

        .serve-card h3 {
            color: var(--primary);
            margin-bottom: 0.8rem;
            font-size: 1.2rem;
            display: inline-flex;
            align-items: center;
        }

        .serve-card p {
            color: var(--muted);
        }

        /* Footer */
        footer {
            background: var(--dark);
            color: #cbd5e1;
            padding: 3rem 5%;
            text-align: center;
            font-size: 0.9rem;
        }

        footer p {
            margin-bottom: 0.5rem;
        }

        footer p:first-child {
            color: #fff;
            font-weight: 600;
            font-size: 1rem;
        }

        :root {
            --primary: #245d4b;
            --primary-dark: #183f34;
            --secondary: #477d68;
            --accent: #e47a56;
            --accent-dark: #bd5d3c;
            --light: #f5f3eb;
            --dark: #202c27;
            --muted: #69746e;
            --card-bg: #fffefa;
            --shadow-sm: 0 2px 10px rgba(32, 44, 39, 0.06);
            --shadow-md: 0 14px 36px rgba(32, 44, 39, 0.09);
            --shadow-lg: 0 22px 50px rgba(21, 45, 36, 0.17);
            --radius: 8px;
            --radius-sm: 6px;
        }

        * { font-family: 'Manrope', sans-serif; }

        body {
            background: #fbfaf6;
            line-height: 1.65;
        }

        nav {
            padding: 0.85rem 5%;
            background: rgba(251, 250, 246, 0.96);
            border-bottom: 1px solid rgba(32, 44, 39, 0.08);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.65rem;
            font-size: 1.1rem;
            letter-spacing: 0;
        }

        .logo-mark {
            display: grid;
            place-items: center;
            width: 38px;
            height: 38px;
            border-radius: 6px;
            color: #fff;
            background: var(--primary);
            font-size: 0.86rem;
            font-weight: 800;
        }

        .nav-links { display: flex; align-items: center; gap: 1.8rem; }
        .nav-links a { margin-left: 0; font-size: 0.9rem; }

        .btn-login {
            padding: 0.65rem 1.15rem;
            background: var(--primary);
        }

        .hero {
            min-height: 680px;
            padding: 5.5rem 5%;
            background: #173d33;
            isolation: isolate;
        }

        .hero-bg {
            background-position: center 44%;
            filter: saturate(0.78);
            z-index: 0;
        }

        .hero-overlay {
            background: linear-gradient(100deg, rgba(15, 43, 35, 0.76) 0%, rgba(20, 58, 46, 0.58) 54%, rgba(16, 40, 33, 0.62) 100%);
            z-index: 1;
        }

        .hero-container {
            max-width: 1240px;
            position: relative;
            z-index: 2;
            grid-template-columns: 0.92fr 1.08fr;
            gap: 4rem;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 0.55rem;
            margin-bottom: 1.25rem;
            color: #f3c9a7;
            font-size: 0.76rem;
            font-weight: 800;
            text-transform: uppercase;
        }

        .eyebrow::before {
            content: '';
            width: 24px;
            height: 2px;
            background: var(--accent);
        }

        .hero h1, .section-heading h2 {
            font-family: 'DM Serif Display', Georgia, serif;
            font-weight: 400;
            letter-spacing: 0;
        }

        .hero h1 {
            max-width: 610px;
            font-size: clamp(2.6rem, 4.5vw, 4.25rem);
            line-height: 1.08;
            margin-bottom: 1.25rem;
        }

        .hero p {
            max-width: 540px;
            color: rgba(255, 255, 255, 0.84);
            font-size: 1rem;
            margin-bottom: 1.8rem;
        }

        .hero-actions { display: flex; flex-wrap: wrap; gap: 0.8rem; }

        .btn-primary, .btn-secondary {
            margin: 0;
            padding: 0.85rem 1.25rem;
            border-radius: 6px;
            font-size: 0.9rem;
        }

        .btn-primary {
            background: var(--accent);
            box-shadow: none;
        }

        .btn-primary:hover { background: var(--accent-dark); box-shadow: none; }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.42);
        }

        .hero-graphic { animation: fadeInUp 0.9s 0.1s both ease-out; }

        .dashboard {
            max-width: 550px;
            margin-left: auto;
            padding: 1.35rem;
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 8px;
            color: var(--dark);
            background: #fffefa;
            box-shadow: 0 28px 70px rgba(9, 28, 21, 0.3);
            transform: rotate(1.2deg);
        }

        .dashboard-top, .dashboard-title-row, .student-row, .metric-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .dashboard-top { padding-bottom: 1rem; border-bottom: 1px solid #e9e9e2; }
        .dashboard-brand { color: var(--primary); font-size: 0.75rem; font-weight: 800; }
        .dashboard-term { color: var(--muted); font-size: 0.65rem; }
        .dashboard-title-row { align-items: flex-end; padding: 1rem 0 0.85rem; }
        .dashboard-title { font-size: 1rem; font-weight: 800; }
        .dashboard-caption { color: var(--muted); font-size: 0.68rem; }
        .dashboard-grade { color: var(--primary); font-size: 0.73rem; font-weight: 800; }
        .metric-row { gap: 0.65rem; align-items: stretch; }

        .metric {
            flex: 1;
            padding: 0.7rem;
            border: 1px solid #e9e9e2;
            border-radius: 6px;
            background: #fbfaf6;
        }

        .metric-label { color: var(--muted); font-size: 0.61rem; }
        .metric-value { margin-top: 0.15rem; color: var(--primary); font-size: 1.08rem; font-weight: 800; }
        .student-list { margin-top: 1rem; }
        .student-row { gap: 0.6rem; padding: 0.65rem 0; border-top: 1px solid #eeeee8; }
        .student-name { flex: 1; font-size: 0.68rem; font-weight: 700; }
        .student-subject { color: var(--muted); font-size: 0.59rem; }
        .student-score { min-width: 38px; color: var(--primary); font-size: 0.68rem; font-weight: 800; text-align: right; }
        .progress-track { width: 60px; height: 5px; overflow: hidden; border-radius: 8px; background: #e9e9e2; }
        .progress-fill { height: 100%; border-radius: inherit; background: #6b9a70; }
        .progress-fill.needs-support { background: var(--accent); }

        .features { padding: 5.5rem 5%; background: #f3f1e9; }
        .section-heading { margin-bottom: 2.5rem; }
        .section-heading h2 { color: var(--primary-dark); font-size: 2.6rem; }
        .section-heading p { max-width: 620px; margin: 0 auto; font-size: 0.98rem; }
        .features-grid { gap: 1rem; }

        .feature-card {
            min-height: 210px;
            padding: 1.6rem;
            border: 1px solid #e6e4dc;
            border-top: 2px solid var(--primary);
            border-radius: 6px;
            box-shadow: none;
        }

        .feature-card:nth-child(2) { border-top-color: #6b9a70; }
        .feature-card:nth-child(3) { border-top-color: #d6a344; }
        .feature-card:nth-child(4) { border-top-color: var(--accent); }
        .feature-card:nth-child(5) { border-top-color: #7797a2; }
        .feature-card:nth-child(6) { border-top-color: #8c8069; }
        .feature-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-md); }
        .feature-card h3 { font-size: 1rem; }
        .feature-card p, .serve-card p { font-size: 0.9rem; }

        .serve { padding: 5.5rem 5%; background: #fbfaf6; }
        .serve-grid { gap: 1rem; }

        .serve-card {
            padding: 2rem 1.5rem;
            border: 1px solid #e7e5dd;
            border-radius: 6px;
            background: #fffefa;
        }

        .serve-card:hover { border-color: var(--primary); transform: translateY(-3px); box-shadow: var(--shadow-md); }
        .serve-card h3 { font-size: 1.05rem; }

        footer {
            padding: 2.5rem 5%;
            background: #183f34;
        }

        a:focus-visible, .tooltip:focus-visible {
            outline: 3px solid #e9a27d;
            outline-offset: 4px;
        }

        @media (max-width: 900px) {
            .hero-container { grid-template-columns: 1fr 1fr; gap: 2rem; }
            .hero h1 { font-size: 3rem; }
            .dashboard { padding: 1rem; }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .nav-container { flex-wrap: wrap; gap: 0.7rem; }
            .nav-links { width: 100%; justify-content: space-between; gap: 0.5rem; }
            .nav-links a { margin: 0; font-size: 0.78rem; }
            .hero { min-height: auto; padding: 4rem 6%; }
            .hero-container {
                grid-template-columns: 1fr;
                text-align: center;
                gap: 2rem;
            }
            .hero-content { display: flex; flex-direction: column; align-items: center; }
            .hero h1 { font-size: 2.8rem; }
            .hero-graphic { width: 100%; }
            .dashboard { margin: 0 auto; transform: none; text-align: left; }
            .features-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .tooltip-text {
                left: auto;
                right: 0;
                width: min(280px, calc(100vw - 40px));
                min-width: 0;
                max-width: calc(100vw - 40px);
                transform: translateY(6px);
            }
            .tooltip:hover .tooltip-text { transform: translateY(0); }
        }

        @media (max-width: 520px) {
            .nav-links { flex-wrap: wrap; justify-content: flex-start; column-gap: 1rem; row-gap: 0.7rem; }
            .nav-links .btn-login { margin-left: auto; }
            .hero { padding: 3.5rem 5%; }
            .hero h1 { font-size: 2.45rem; }
            .hero p { font-size: 0.92rem; }
            .hero-actions { justify-content: center; }
            .section-heading h2 { font-size: 2.2rem; }
            .features-grid, .serve-grid { grid-template-columns: 1fr; }
            .feature-card { min-height: auto; }
            .metric-row { gap: 0.4rem; }
            .metric { padding: 0.55rem; }
            .student-subject { display: none; }
            .progress-track { width: 48px; }
        }

        @media (max-width: 360px) {
            .hero h1 { font-size: 2rem; }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                scroll-behavior: auto !important;
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }

        body {
            color: #eaf0ec;
            background: #101915;
        }

        nav {
            background: rgba(16, 25, 21, 0.96);
            border-bottom: 1px solid #2c3a31;
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.18);
        }

        .logo { color: #a8d3b2; }
        .nav-links a { color: #d6e0d9; }
        .nav-links a:hover { color: #b6d9bf; }
        .nav-links a::after { background: #e49b71; }

        .btn-login {
            color: #102017 !important;
            background: #9ac9a7;
        }

        .btn-login:hover { background: #b6d9bf; box-shadow: 0 6px 18px rgba(0, 0, 0, 0.24); }
        .features { background: #141f19; }
        .section-heading h2 { color: #a8d3b2; }
        .section-heading p { color: #b1beb5; }

        .feature-card {
            border-color: #344239;
            background: #1a251f;
            color: #eaf0ec;
        }

        .feature-card h3 { color: #c1e3c9; }
        .feature-card p { color: #b1beb5; }
        .feature-card:hover { box-shadow: 0 18px 38px rgba(0, 0, 0, 0.25); }
        .tooltip-icon { color: #c1e3c9; background: #2a3a30; }
        .tooltip:hover .tooltip-icon { color: #102017; background: #9ac9a7; }
        .tooltip-text { color: #edf4ef; background: #26352c; }
        .tooltip-text::after { border-color: #26352c transparent transparent transparent; }
        .serve { background: #101915; }

        .serve-card {
            border-color: #344239;
            color: #eaf0ec;
            background: linear-gradient(145deg, #1b2821, #17211b);
        }

        .serve-card h3 { color: #c1e3c9; }
        .serve-card p { color: #b1beb5; }
        .serve-card:hover { border-color: #739b7d; box-shadow: 0 18px 38px rgba(0, 0, 0, 0.25); }
        footer { background: #0b120e; border-top: 1px solid #2c3a31; }

        @media (max-width: 768px) {
            nav { background: rgba(16, 25, 21, 0.98); }
        }

        .community { padding: 4.5rem 5%; background: #18251e; }
        .community-container, .subscribe-container { max-width: 1000px; margin: 0 auto; }
        .community-heading { margin-bottom: 2rem; }
        .community-heading h2, .subscribe h2 { color: #a8d3b2; font-family: 'DM Serif Display', Georgia, serif; font-size: 2.4rem; font-weight: 400; }
        .community-heading p, .subscribe p { margin-top: 0.5rem; color: #b1beb5; }
        .community-stats { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); border-top: 1px solid #405247; border-bottom: 1px solid #405247; }
        .community-stat { display: flex; align-items: center; gap: 1rem; min-height: 135px; padding: 1.5rem; }
        .community-stat + .community-stat { border-left: 1px solid #405247; }
        .community-icon { display: grid; place-items: center; width: 48px; height: 48px; flex: 0 0 48px; border: 1px solid #557260; border-radius: 50%; color: #efb28e; font-size: 1.2rem; }
        .community-number { display: block; color: #f2f6f2; font-size: 2rem; font-weight: 800; line-height: 1.2; }
        .community-label { color: #b1beb5; font-size: 0.85rem; }
        .subscribe { padding: 4.5rem 5%; background: #f3f1e9; }
        .subscribe-container { max-width: 680px; text-align: center; }
        .subscribe h2 { color: #183f34; }
        .subscribe p { margin-bottom: 1.5rem; color: #69746e; }
        .subscribe-form { display: flex; gap: 0.65rem; }
        .subscribe-input { min-width: 0; min-height: 50px; flex: 1; padding: 0.8rem 1rem; border: 1px solid #c9cec7; border-radius: 5px; color: #202c27; background: #fffefa; font: inherit; }
        .subscribe-input:focus { border-color: #245d4b; outline: 3px solid rgba(36, 93, 75, 0.16); }
        .subscribe-button { min-height: 50px; padding: 0.8rem 1.35rem; border: 0; border-radius: 5px; color: #fff; background: #245d4b; font: inherit; font-weight: 800; cursor: pointer; }
        .subscribe-button:hover { background: #183f34; }
        .subscribe-message { margin-top: 1rem; padding: 0.75rem 1rem; border-radius: 5px; font-size: 0.88rem; }
        .subscribe-message.success { color: #245d4b; background: #e6f1e8; }
        .subscribe-message.info { color: #305b70; background: #e7f0f3; }
        .subscribe-message.error { color: #733d2b; background: #fff0e9; }
        .registration { padding: 4.5rem 5%; background: #101915; }
        .registration-container { max-width: 760px; margin: 0 auto; }
        .registration h2 { color: #a8d3b2; font-family: 'DM Serif Display', Georgia, serif; font-size: 2.4rem; font-weight: 400; }
        .registration-intro { margin: 0.5rem 0 1.5rem; color: #b1beb5; }
        .registration-form { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px; }
        .registration-field { display: flex; flex-direction: column; gap: 6px; }
        .registration-field label { color: #e4ece6; font-size: 0.82rem; font-weight: 700; }
        .registration-field input { width: 100%; min-height: 48px; padding: 10px 12px; border: 1px solid #46564b; border-radius: 5px; color: #f0f5f1; background: #121a15; font: inherit; }
        .registration-field input:focus { border-color: #9ac9a7; outline: 3px solid rgba(121, 179, 139, 0.18); }
        .registration-password, .registration-form .subscribe-button, .registration-form-note { grid-column: 1 / -1; }
        .registration-form .subscribe-button { justify-self: start; min-width: 170px; }
        .registration-form-note { margin: 0; color: #9aa89f; font-size: 0.75rem; }
        .registration .subscribe-message { margin-bottom: 1rem; }
        .visually-hidden { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0; }

        @media (max-width: 520px) {
            .community, .subscribe, .registration { padding: 3.5rem 5%; }
            .community-heading h2, .subscribe h2, .registration h2 { font-size: 2rem; }
            .community-stat { min-height: 110px; gap: 0.7rem; padding: 1rem 0.65rem; }
            .community-icon { width: 38px; height: 38px; flex-basis: 38px; font-size: 1rem; }
            .community-number { font-size: 1.55rem; }
            .community-label { font-size: 0.72rem; }
            .subscribe-form { flex-direction: column; }
            .registration-form { grid-template-columns: 1fr; }
            .registration-password, .registration-form .subscribe-button, .registration-form-note { grid-column: auto; }
            .registration-form .subscribe-button { width: 100%; }
        }

    </style>
</head>
<body>
 
<!-- Navigation -->
<nav>
    <div class="nav-container">
        <div class="logo"><span class="logo-mark">E</span><span>EARS</span></div>
        <div class="nav-links">
            <a href="#features">Features</a>
            <a href="#about">About</a>
            <a href="#community">Community</a>
            <a href="#register">Register</a>
            <a href="#subscribe">Subscribe</a>
            <a href="#contact">Contact</a>
            <a href="#register" class="btn-login">Register</a>
        </div>
    </div>
</nav>

<!-- Hero Section with Elementary School Background -->
<section class="hero">
    <div class="hero-bg"></div>
    <div class="hero-overlay"></div>
    <div class="hero-container">
        <div class="hero-content">
            <span class="eyebrow">Elementary learning, understood</span>
            <h1>Elementary Assessment and Recommendation System</h1>
            <p>A DepEd-aligned platform to track progress, identify learning needs, and give every child the right support at the right time.</p>
            <div class="hero-actions">
                <a href="#register" class="btn-primary">Create an Account</a>
                <a href="#features" class="btn-secondary">Explore the system</a>
            </div>
        </div>
        <div class="hero-graphic">
            <div class="dashboard" aria-label="Preview of a student progress dashboard">
                <div class="dashboard-top">
                    <span class="dashboard-brand">LEARNER OVERVIEW</span>
                    <span class="dashboard-term">S.Y. 2025–2026 · 2nd Quarter</span>
                </div>
                <div class="dashboard-title-row">
                    <div>
                        <div class="dashboard-title">Grade 4 · Sampaguita</div>
                        <div class="dashboard-caption">Class progress at a glance</div>
                    </div>
                    <span class="dashboard-grade">VIEW CLASS</span>
                </div>
                <div class="metric-row">
                    <div class="metric"><div class="metric-label">ASSESSMENTS</div><div class="metric-value">24</div></div>
                    <div class="metric"><div class="metric-label">ON TRACK</div><div class="metric-value">82%</div></div>
                    <div class="metric"><div class="metric-label">NEEDS SUPPORT</div><div class="metric-value">5</div></div>
                </div>
                <div class="student-list">
                    <div class="student-row"><span class="student-name">Maria Santos</span><span class="student-subject">Reading · Strong progress</span><span class="progress-track"><span class="progress-fill" style="display:block;width:88%"></span></span><span class="student-score">88%</span></div>
                    <div class="student-row"><span class="student-name">Joshua Reyes</span><span class="student-subject">Math · Building skills</span><span class="progress-track"><span class="progress-fill" style="display:block;width:72%"></span></span><span class="student-score">72%</span></div>
                    <div class="student-row"><span class="student-name">Angela Cruz</span><span class="student-subject">Science · Follow-up</span><span class="progress-track"><span class="progress-fill needs-support" style="display:block;width:54%"></span></span><span class="student-score">54%</span></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="registration" id="register" aria-labelledby="registration-heading">
    <div class="registration-container">
        <span class="eyebrow">Join the EARS community</span>
        <h2 id="registration-heading">Create an Account</h2>
        <p class="registration-intro">Register as a parent or guardian to get started.</p>
        <?php if ($registrationMessage !== ''): ?>
            <div class="subscribe-message <?= escape($registrationMessageType) ?>" role="<?= $registrationMessageType === 'error' ? 'alert' : 'status' ?>"><?= escape($registrationMessage) ?></div>
        <?php endif; ?>
        <form class="registration-form" method="post" action="login.php">
            <input type="hidden" name="csrf_token" value="<?= escape(csrf_token()) ?>">
            <input type="hidden" name="action" value="register">
            <div class="registration-field">
                <label for="register-name">Full name</label>
                <input id="register-name" name="full_name" type="text" maxlength="160" autocomplete="name" value="<?= escape($registrationName) ?>" required>
            </div>
            <div class="registration-field">
                <label for="register-email">Email address</label>
                <input id="register-email" name="email" type="email" maxlength="190" autocomplete="email" value="<?= escape($registrationEmail) ?>" required>
            </div>
            <div class="registration-field registration-password">
                <label for="register-password">Password (at least 12 characters)</label>
                <input id="register-password" name="password" type="password" minlength="12" autocomplete="new-password" required>
            </div>
            <p class="registration-form-note">Your password is securely hashed before it is stored.</p>
            <button class="subscribe-button" type="submit">Register</button>
        </form>
    </div>
</section>

<section class="community" id="community" aria-labelledby="community-heading">
    <div class="community-container">
        <div class="community-heading">
            <span class="eyebrow">Growing together</span>
            <h2 id="community-heading">Our Community</h2>
            <p>Families and educators working together to support every learner.</p>
        </div>
        <div class="community-stats">
            <div class="community-stat">
                <span class="community-icon" aria-hidden="true">&#9786;</span>
                <div><strong class="community-number" id="registered-account-count" aria-live="polite" aria-atomic="true"><?= number_format($registeredCount) ?></strong><span class="community-label">Registered Accounts</span></div>
            </div>
            <div class="community-stat">
                <span class="community-icon" aria-hidden="true">&#9993;</span>
                <div><strong class="community-number"><?= number_format($subscriberCount) ?></strong><span class="community-label">Subscribers</span></div>
            </div>
        </div>
    </div>
</section>

<section class="subscribe" id="subscribe" aria-labelledby="subscribe-heading">
    <div class="subscribe-container">
        <h2 id="subscribe-heading">Stay Updated</h2>
        <p>Subscribe to receive news and updates about the system.</p>
        <form class="subscribe-form" method="post" action="index.php#subscribe">
            <input type="hidden" name="csrf_token" value="<?= escape(csrf_token()) ?>">
            <input type="hidden" name="action" value="subscribe">
            <label class="visually-hidden" for="subscriber-email">Email address</label>
            <input class="subscribe-input" id="subscriber-email" name="email" type="email" maxlength="190" placeholder="Enter your email address" autocomplete="email" required>
            <button class="subscribe-button" type="submit">Subscribe</button>
        </form>
        <?php if ($subscribeMessage !== ''): ?>
            <div class="subscribe-message <?= escape($subscribeMessageType) ?>" role="status"><?= escape($subscribeMessage) ?></div>
        <?php endif; ?>
    </div>
</section>

<!-- Features Section with Tooltips -->
<section class="features" id="features">
    <div class="section-heading">
        <h2>How It Helps</h2>
        <p>Designed to make assessment clear, timely, and useful for every learner — aligned with DepEd standards.</p>
    </div>
    <div class="features-grid">
        <div class="feature-card">
            <h3>📊 Easy Progress Tracking
                <span class="tooltip">
                    <span class="tooltip-icon">?</span>
                    <span class="tooltip-text">Record grades, scores, and notes in one place. Results are organized and accessible anytime.</span>
                </span>
            </h3>
            <p>Record, organize, and access assessment results quickly — no more lost records or delayed updates.</p>
        </div>

        <div class="feature-card">
            <h3>🎯 Identify Learning Needs
                <span class="tooltip">
                    <span class="tooltip-icon">?</span>
                    <span class="tooltip-text">See exactly which subjects or skills need attention before learning gaps become larger.</span>
                </span>
            </h3>
            <p>See clearly which subjects, skills, or lessons need extra attention before gaps grow larger.</p>
        </div>

        <div class="feature-card">
            <h3>🤝 Home-School Connection
                <span class="tooltip">
                    <span class="tooltip-icon">?</span>
                    <span class="tooltip-text">Parents and teachers see the same updates. No more waiting for meetings to share important information.</span>
                </span>
            </h3>
            <p>Share performance updates and recommendations promptly so parents and teachers work as one team.</p>
        </div>

        <div class="feature-card">
            <h3>💡 Targeted Recommendations
                <span class="tooltip">
                    <span class="tooltip-icon">?</span>
                    <span class="tooltip-text">Get specific activities and practice suggestions based on actual performance data, not guesswork.</span>
                </span>
            </h3>
            <p>Get specific learning activities and support suggestions based on each child's actual performance.</p>
        </div>

        <div class="feature-card">
            <h3>⚡ Early Support
                <span class="tooltip">
                    <span class="tooltip-icon">?</span>
                    <span class="tooltip-text">Spot students who need help early. Timely support keeps learners confident and on track.</span>
                </span>
            </h3>
            <p>Spot students who need help early and provide timely intervention to keep them on track.</p>
        </div>

        <div class="feature-card">
            <h3>🔒 Safe & Compliant
                <span class="tooltip">
                    <span class="tooltip-icon">?</span>
                    <span class="tooltip-text">Follows DepEd Data Privacy Act. Student information is protected and never shared publicly.</span>
                </span>
            </h3>
            <p>Follows DepEd data privacy standards — student information is protected and secure.</p>
        </div>
    </div>
</section>

<!-- Who We Serve with Tooltips -->
<section class="serve" id="about">
    <div class="section-heading">
        <h2>Who This Is For</h2>
        <p>Built together with and for the people who care most about our learners.</p>
    </div>
    <div class="serve-grid">
        <div class="serve-card">
            <h3>👩‍🏫 Teachers
                <span class="tooltip">
                    <span class="tooltip-icon">?</span>
                    <span class="tooltip-text">Manage classes, record assessments, and generate recommendations for every student.</span>
                </span>
            </h3>
            <p>Simplify grading, monitoring, and making recommendations for every student in your class.</p>
        </div>

        <div class="serve-card">
            <h3>👨‍👩‍👧‍👦 Parents & Guardians
                <span class="tooltip">
                    <span class="tooltip-icon">?</span>
                    <span class="tooltip-text">View your child's progress, strengths, and recommended activities to support learning at home.</span>
                </span>
            </h3>
            <p>Stay updated on your child's strengths, progress, and how you can support learning at home.</p>
        </div>

        <div class="serve-card">
            <h3>🏫 School Principal
                <span class="tooltip">
                    <span class="tooltip-icon">?</span>
                    <span class="tooltip-text">Oversee school-wide data, ensure standards compliance, and support teachers effectively.</span>
                </span>
            </h3>
            <p>Monitor school-wide performance and ensure DepEd standards are followed consistently.</p>
        </div>
    </div>
</section>

<!-- Footer -->
<footer id="contact">
    <p>Elementary Assessment and Recommendation System</p>
    <p style="margin: 0.5rem 0;">DepEd-Aligned • For Elementary Education</p>
    <p>© 2026 All Rights Reserved | Data Privacy Compliant</p>
</footer>

<script>
    const registeredAccountCount = document.getElementById('registered-account-count');
    let latestAccountCount = Number(registeredAccountCount.textContent.replace(/,/g, ''));

    async function refreshRegisteredAccountCount() {
        try {
            const response = await fetch('account_count.php', { cache: 'no-store' });
            if (!response.ok) return;

            const data = await response.json();
            if (!Number.isInteger(data.count) || data.count === latestAccountCount) return;

            latestAccountCount = data.count;
            registeredAccountCount.textContent = new Intl.NumberFormat().format(data.count);
        } catch (error) {
            // Keep the last known count visible if the network is temporarily unavailable.
        }
    }

    window.setInterval(refreshRegisteredAccountCount, 2000);
</script>

</body>
</html>