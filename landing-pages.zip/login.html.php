<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$success = '';
$fullName = '';
$email = '';
$setupAvailable = false;
$databaseError = false;

try {
    $pdo = database();
    $setupAvailable = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() === 0;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = input_string('action');
        $fullName = input_string('full_name');
        $email = input_string('email');
        $password = input_string('password');

        if (!valid_csrf_token()) {
            $error = 'Your session expired. Refresh the page and try again.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
            $error = 'Enter a valid email address and password.';
        } elseif ($action === 'register' && ($fullName === '' || strlen($fullName) > 160)) {
            $error = 'Enter your full name to register.';
        } elseif ($action === 'register' && strlen($password) < 12) {
            $error = 'Choose a password with at least 12 characters to register.';
        } elseif ($action === 'register') {
            try {
                $statement = $pdo->prepare(
                    'INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, \'parent\')'
                );
                $statement->execute([$fullName, $email, password_hash($password, PASSWORD_DEFAULT)]);
                unset($_SESSION['user_id'], $_SESSION['demo_mode'], $_SESSION['demo_email']);
                $_SESSION['registration_message'] = 'Account created successfully. You can now sign in.';
                $_SESSION['registration_message_type'] = 'success';
                header('Location: index.php#register');
                exit;
            } catch (PDOException $exception) {
                $error = $exception->getCode() === '23000'
                    ? 'An account already uses that email. Try another email address.'
                    : 'Your account could not be created. Please try again.';
            }
        } else {
            $statement = $pdo->prepare(
                'SELECT id, full_name, email, password_hash, role FROM users WHERE email = ? AND is_active = 1 LIMIT 1'
            );
            $statement->execute([$email]);
            $user = $statement->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = (int) $user['id'];
                unset($_SESSION['demo_mode'], $_SESSION['demo_email']);
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                header('Location: dashboard.php');
                exit;
            }

            session_regenerate_id(true);
            unset($_SESSION['user_id']);
            $_SESSION['demo_mode'] = true;
            $_SESSION['demo_email'] = $email;
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            header('Location: dashboard.php');
            exit;
        }

        if ($action === 'register') {
            $_SESSION['registration_message'] = $error;
            $_SESSION['registration_message_type'] = 'error';
            $_SESSION['registration_name'] = $fullName;
            $_SESSION['registration_email'] = $email;
            header('Location: index.php#register');
            exit;
        }
    }
} catch (PDOException $exception) {
    $databaseError = true;
}

$notice = isset($_GET['registered'])
    ? 'Account created successfully. You can sign in when you are ready.'
    : (isset($_GET['logged_out']) ? 'You have been signed out.' : '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | EARS</title>
    <link rel="stylesheet" href="auth.css">
</head>
<body>
<main class="auth-shell">
    <section class="auth-story" aria-label="Elementary learning">
        <a class="brand" href="index.php"><span class="brand-mark">E</span><span>EARS</span></a>
        <div class="story-copy">
            <p class="eyebrow">Elementary learning, understood</p>
            <h1>Join your learning community.</h1>
            <p>Create a parent or guardian account to support every learner with timely progress and practical next steps.</p>
        </div>
        <div class="story-foot">Elementary Assessment and Recommendation System</div>
    </section>
    <section class="auth-main">
        <div class="form-panel">
            <p class="form-kicker">Secure school portal</p>
            <h2>Join EARS</h2>
            <p class="form-intro">Create a parent or guardian account to get started with EARS.</p>

            <?php if ($databaseError): ?>
                <div class="alert" role="alert">The database could not be reached. Check that XAMPP MySQL is running and that the <strong>ears_db</strong> database is installed.</div>
            <?php endif; ?>
            <?php if ($notice !== ''): ?>
                <div class="alert success" role="status"><?= escape($notice) ?></div>
            <?php endif; ?>
            <?php if ($success !== ''): ?>
                <div class="alert success" role="status"><?= escape($success) ?></div>
            <?php endif; ?>
            <?php if ($error !== ''): ?>
                <div class="alert" id="login-error" role="alert" tabindex="-1"><?= escape($error) ?></div>
            <?php endif; ?>

            <form method="post" action="login.php" autocomplete="on">
                <input type="hidden" name="csrf_token" value="<?= escape(csrf_token()) ?>">
                <div class="field">
                    <label for="full_name">Full name <span class="optional-label">(required to register)</span></label>
                    <input id="full_name" name="full_name" type="text" value="<?= escape($fullName) ?>" maxlength="160" autocomplete="name" required>
                </div>
                <div class="field">
                    <label for="email">Email address</label>
                    <input id="email" name="email" type="email" value="<?= escape($email) ?>" autocomplete="email" aria-describedby="email-hint" required>
                    <span class="field-hint" id="email-hint">Use the email address linked to your school account.</span>
                </div>
                <div class="field">
                    <label for="password">Password</label>
                    <div class="password-control">
                        <input id="password" name="password" type="password" minlength="12" autocomplete="new-password" <?= $error !== '' ? 'aria-describedby="login-error" autofocus' : 'aria-describedby="password-hint"' ?> required>
                        <button class="password-toggle" type="button" aria-controls="password" aria-label="Show password" aria-pressed="false">Show</button>
                    </div>
                    <span class="field-hint" id="password-hint">Your password is case-sensitive.</span>
                </div>
                <div class="auth-actions">
                    <button class="primary-button" id="register-submit" type="submit" name="action" value="register">Register</button>
                </div>
            </form>

            <?php if ($setupAvailable): ?>
                <p class="form-note">No accounts exist yet. <a href="setup.php">Create the first administrator account</a>.</p>
            <?php elseif ($databaseError): ?>
                <p class="form-note"><a href="setup.php">Initial administrator setup</a></p>
            <?php endif; ?>
            <p class="form-note"><a href="index.php">Return to the home page</a></p>
        </div>
    </section>
</main>
<script>
    const passwordInput = document.getElementById('password');
    const passwordToggle = document.querySelector('.password-toggle');
    const loginForm = document.querySelector('form[action="login.php"]');
    const submitButtons = loginForm.querySelectorAll('button[type="submit"]');

    passwordToggle.addEventListener('click', () => {
        const shouldReveal = passwordInput.type === 'password';
        passwordInput.type = shouldReveal ? 'text' : 'password';
        passwordToggle.textContent = shouldReveal ? 'Hide' : 'Show';
        passwordToggle.setAttribute('aria-label', shouldReveal ? 'Hide password' : 'Show password');
        passwordToggle.setAttribute('aria-pressed', String(shouldReveal));
        passwordInput.focus();
    });

    loginForm.addEventListener('submit', (event) => {
        const button = event.submitter;
        if (!button) return;

        button.disabled = true;
        button.textContent = 'Creating account...';
        submitButtons.forEach((submitButton) => {
            if (submitButton !== button) submitButton.disabled = true;
        });
    });
</script>
</body>
</html>