<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');

session_name('ears_session');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

function database(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $host = getenv('EARS_DB_HOST') ?: '127.0.0.1';
    $name = getenv('EARS_DB_NAME') ?: 'ears_db';
    $user = getenv('EARS_DB_USER') ?: 'root';
    $password = getenv('EARS_DB_PASS') ?: '';
    $dsn = "mysql:host={$host};dbname={$name};charset=utf8mb4";

    $pdo = new PDO($dsn, $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    return $pdo;
}

function escape(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function input_string(string $key): string
{
    $value = $_POST[$key] ?? '';
    if (!is_string($value)) {
        return '';
    }

    return in_array($key, ['password', 'confirm_password'], true) ? $value : trim($value);
}

function csrf_token(): string
{
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function valid_csrf_token(): bool
{
    $submitted = $_POST['csrf_token'] ?? '';
    return is_string($submitted)
        && isset($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $submitted);
}

function require_login(): array
{
    if (($_SESSION['demo_mode'] ?? false) === true) {
        $demoEmail = $_SESSION['demo_email'] ?? 'demo@example.invalid';

        return [
            'id' => 0,
            'full_name' => 'Demo Educator',
            'email' => is_string($demoEmail) ? $demoEmail : 'demo@example.invalid',
            'role' => 'demo',
            'created_at' => null,
            'demo_mode' => true,
        ];
    }

    $userId = $_SESSION['user_id'] ?? null;
    if (!is_int($userId) && !ctype_digit((string) $userId)) {
        header('Location: login.php');
        exit;
    }

    $statement = database()->prepare(
        'SELECT id, full_name, email, role, created_at FROM users WHERE id = ? AND is_active = 1 LIMIT 1'
    );
    $statement->execute([(int) $userId]);
    $user = $statement->fetch();

    if (!$user) {
        $_SESSION = [];
        session_destroy();
        header('Location: login.php');
        exit;
    }

    return $user;
}