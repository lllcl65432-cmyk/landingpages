<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$databaseError = false;
$setupAvailable = false;
$fullName = '';
$email = '';
$createdUserId = 0;

try {
    $pdo = database();
    $setupAvailable = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() === 0;

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $setupAvailable) {
        $fullName = input_string('full_name');
        $email = input_string('email');
        $password = input_string('password');
        $confirmPassword = input_string('confirm_password');

        if (!valid_csrf_token()) {
            $error = 'Your session expired. Refresh the page and try again.';
        } elseif ($fullName === '' || strlen($fullName) > 160) {
            $error = 'Enter your name (up to 160 characters).';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
            $error = 'Enter a valid email address.';
        } elseif (strlen($password) < 12) {
            $error = 'Choose a password with at least 12 characters.';
        } elseif ($password !== $confirmPassword) {
            $error = 'The passwords do not match.';
        } else {
            $lockAcquired = (int) $pdo->query("SELECT GET_LOCK('ears_initial_admin_setup', 5)")->fetchColumn() === 1;

            if (!$lockAcquired) {
                $error = 'Initial setup is busy. Wait a moment and try again.';
            } else {
                try {
                    $pdo->beginTransaction();
                    $accountCount = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
                    if ($accountCount > 0) {
                        $pdo->rollBack();
                        $setupAvailable = false;
                        $error = 'An account has already been created. Sign in instead.';
                    } else {
                        $statement = $pdo->prepare(
                            'INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, \'admin\')'
                        );
                        $statement->execute([$fullName, $email, password_hash($password, PASSWORD_DEFAULT)]);
                        $createdUserId = (int) $pdo->lastInsertId();
                        $pdo->commit();
                    }
                } catch (Throwable $exception) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $error = 'The administrator account could not be created. Check that the email is not already in use.';
                } finally {
                    $pdo->query("SELECT RELEASE_LOCK('ears_initial_admin_setup')");
                }
            }

            if ($createdUserId > 0) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $createdUserId;
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                header('Location: dashboard.php');
                exit;
            }
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && !$setupAvailable) {
        $error = 'Initial setup has already been completed. Sign in with an existing account.';
    }
} catch (PDOException $exception) {
    $databaseError = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First administrator setup | EARS</title>
    <link rel="stylesheet" href="auth.css">
</head>
<body>
<main class="auth-shell">
    <section class="auth-story" aria-label="Elementary learning">
        <a class="brand" href="index.php"><span class="brand-mark">E</span><span>EARS</span></a>
        <div class="story-copy">
            <p class="eyebrow">One-time setup</p>
            <h1>Start with a protected administrator account.</h1>
            <p>This setup is available only while the system has no user accounts. Your password is stored as a secure hash.</p>
        </div>
        <div class="story-foot">Elementary Assessment and Recommendation System</div>
    </section>
    <section class="auth-main">
        <div class="form-panel">
            <h2>First administrator</h2>
            <p class="form-intro">Create the account that will manage access to the system.</p>
            <?php if ($databaseError): ?>
                <div class="alert">The database could not be reached. Check that XAMPP MySQL is running and that the <strong>ears_db</strong> database is installed.</div>
            <?php endif; ?>
            <?php if (!$setupAvailable && !$databaseError): ?>
                <div class="alert success">Initial setup is complete. Sign in with an existing account.</div>
            <?php endif; ?>
            <?php if ($error !== ''): ?>
                <div class="alert" role="alert"><?= escape($error) ?></div>
            <?php endif; ?>

            <?php if ($setupAvailable): ?>
                <form method="post" action="setup.php" autocomplete="on">
                    <input type="hidden" name="csrf_token" value="<?= escape(csrf_token()) ?>">
                    <div class="field">
                        <label for="full_name">Full name</label>
                        <input id="full_name" name="full_name" type="text" value="<?= escape($fullName) ?>" autocomplete="name" maxlength="160" required autofocus>
                    </div>
                    <div class="field">
                        <label for="email">Email address</label>
                        <input id="email" name="email" type="email" value="<?= escape($email) ?>" autocomplete="email" maxlength="190" required>
                    </div>
                    <div class="field">
                        <label for="password">Password</label>
                        <input id="password" name="password" type="password" autocomplete="new-password" minlength="12" required>
                    </div>
                    <div class="field">
                        <label for="confirm_password">Confirm password</label>
                        <input id="confirm_password" name="confirm_password" type="password" autocomplete="new-password" minlength="12" required>
                    </div>
                    <button class="primary-button" type="submit">Create administrator</button>
                </form>
            <?php endif; ?>
            <p class="form-note"><a href="login.php">Go to sign in</a></p>
        </div>
    </section>
</main>
</body>
</html>